jQuery(document).ready(function initSpColorPicker($) {
    $('.sp-color-field').wpColorPicker();
});